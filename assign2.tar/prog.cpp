#include "restaurant.h"

int main(int argc, char *argv[])
{
	//your main function lives here
	return 0;
}