/******************************************************
** Program: assign.cpp
** Author: Adilbek Bazarkulov
** Date: 04/20/2020
** Description: This Program simulates the Pizza portal
where user able to either log in as a employee and have 
options to make some changes, or customer that can't make any
changes in the restaraunt, however have other options such as place order.
** Input:User inputs
** Output:Depends from User's input, might be call of specific functions or change
in restaurant information
******************************************************/

#include "restaurant.h"

int main(int argc, char *argv[])
{
	Restaurant r;
	r.load_data();
	r.start_menu();
	return 0;
}