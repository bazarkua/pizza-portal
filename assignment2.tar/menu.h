#ifndef MENU_H
#define MENU_H 

#include <string>
#include <fstream>
#include "pizza.h"

using namespace std;

class Menu {
  private:
    int num_pizzas;
    Pizza* pizzas;
  public:
  Menu();
   ~Menu();
   Menu(const Menu&);
   Menu& operator=(const Menu&);
    //need to include accessor functions and mutator functions for each private member
    //need to include constructors, copy constructors, assignment operator overload,
    //and destructors where appropriate

    // Only one of the following two prototypes should be used:
    //Menu search_pizza_by_cost(int upper_bound);
    Menu search_pizza_by_cost(int upper_bound, string size);
    //Menu                                        delete results
    //Menu search_pizza_by_ingredients_to_include(string* ingredients, int num_ingredients);
    Menu search_pizza_by_ingredients_to_exclude(string* ingredients, int num_ingredients);
    void add_item_to_menu();
    void remove_item_from_menu();

    void place_order(string order);
    void populate_menu();
    void show_menu();
    void remove_item_at_index(int index);
    int get_cost(int index, string size);
    void search_pizza_by_ingredients_to_include(Menu &results, string* ingredients, int num_ingredients);
    bool check_all_true( bool* arr, int num);
    void search_pizza_by_ingredients_to_exclude(Menu &results, string* ingredients, int num_ingredients);
    void create_array(int length);
};

#endif